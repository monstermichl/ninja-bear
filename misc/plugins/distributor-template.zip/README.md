# ninja-bear-distributor-<distributor-lower>
This [ninja-bear](https://pypi.org/project/ninja-bear) plugin adds the distributor support for <distributor-upper>.
