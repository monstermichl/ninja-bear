# ninja-bear-language-<language-lower>
This [ninja-bear](https://pypi.org/project/ninja-bear) plugin adds support for the <language-upper> programming language.
